import java.util.Scanner;
public class Main{
    public static void main(String[]args){
        Scanner out=new Scanner(System.in);
        int n1=out.nextInt(),n2=out.nextInt();
        int a=out.nextInt();
        if(n1*n2==0){
            System.out.println("fyrst");
        }
        else if(n1==n2){
            System.out.println(n1 +"fyrst");
        }
        else{
            System.out.println("naestfyrst");
        }
    }
}