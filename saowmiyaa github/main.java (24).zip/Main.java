import java.util.Scanner;
public class Main{
    public static void main(String[]args){
        Scanner out=new Scanner(System.in);
        int n1=out.nextInt();
        int n2=out.nextInt();
        out.nextLine();
        String a=out.nextLine();
        String b=out.nextLine();
        if(n1%n2!=0){
            System.out.println(a+"lokud");
        
            System.out.println(b+"opin");
        }
        else{
             System.out.println("none");
        }
    }
}