import java.util.*;

public class Main {
    public static void main(String[] args) {
        List<Integer> arr = new ArrayList<>();

        
        arr.add(10);
        arr.add(20);
        arr.add(30);
        arr.add(40);

       
        int lastNum = arr.get(arr.size() - 1);

       
        arr.remove(arr.size() - 1);

        
        arr.add(50);

        
        System.out.println("Modified List: " + arr);

        
        System.out.println("Removed Last Number: " + lastNum);
    }
}
