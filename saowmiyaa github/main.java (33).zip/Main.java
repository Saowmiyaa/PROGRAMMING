import java.util.Scanner;
public class Main{
    public static void main(String[]args){
        Scanner out=new Scanner(System.in);
        int a=out.nextInt();
        out.nextLine();
        String b=out.nextLine();
        String c=out.nextLine();
        if(a%2!=0){
            System.out.println("Unnar fann hana!");

        }
        else{
            System.out.println("Unnar fann hana ekki!");

        }
    }
    }