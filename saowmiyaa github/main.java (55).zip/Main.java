import java.util.Scanner;
public class Main{
    public static void main(String[]args){
        Scanner out=new Scanner(System.in);
        int num1=out.nextInt(),num2=out.nextInt();
        
        if(num1>num2){
            System.out.println(">");
        }
        else if(num1<num2){
            System.out.println("<");
        }
        else{
            System.out.println("Goggi svangur!");
        }
    }
}