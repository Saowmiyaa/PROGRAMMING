import java.util.Scanner;
import java.util.Random;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        String correctPassword = "java123"; 
        int attempts = 3;  

        while (attempts > 0) {
            System.out.print("Enter password: ");
            String enteredPassword = sc.nextLine();

            if (enteredPassword.equals(correctPassword)) {
                System.out.println("Welcome");

                
                Random rand = new Random();
                int otp = 100000 + rand.nextInt(900000);
                System.out.println("Your OTP is: " + otp);
                
                
                System.out.print("Enter the OTP to confirm login: ");
                int enteredOtp = sc.nextInt();

                if (enteredOtp == otp) {
                    System.out.println("OTP verified. Login Successful");
                } else {
                    System.out.println("OTP mismatching. Login Failed");
                }

                return; 
            } 
            else {
                attempts--;
                if (attempts > 0) {
                    System.out.println("Password mismatching. Try again (" + attempts + " attempts left).");
                } else {
                    System.out.println("Account blocked");
                }
            }
        }

        sc.close();
    }
}
