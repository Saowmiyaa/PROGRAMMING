public class Main {
    public static void main(String[] args) {
        int[] arr = {1, 2, 3, 4, 5};
        int K = 6;

        int n = arr.length;
        boolean first = true; 
        
        for (int i = 0; i < n; i++) {
            for (int j = i + 1; j < n; j++) {
                if (arr[i] + arr[j] < K) {
                    if (!first) {
                        System.out.print(",");
                    }
                    System.out.print("(" + i + "," + j + ")");
                    first = false; 
                    
                }
            }
        }
    }
}
