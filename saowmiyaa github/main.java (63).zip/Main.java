/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
	    Scanner out=new Scanner(System.in);
	    int c1=out.nextInt();
	    int r1=out.nextInt();
	    int c2=out.nextInt();
	    int r2=out.nextInt();
	    int d =c1+r1;
	    int e =c2+r2;
	    
	    if(d<e){
	        System.out.println(1);
	    }
	    else{
	        System.out.println(2); 
	    }
	    
		
	}
}
