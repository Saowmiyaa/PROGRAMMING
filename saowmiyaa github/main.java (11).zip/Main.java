/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/

public class Main
{
	public static void main(String[] args) {
	    int arr[]={17,9,11,6,1};
	    for(int i=0;i<arr.length;i++){
	        boolean b=true;
	    }
	    for(int j=i+1;j<arr;j++){
	        if(arr[i]<arr[j+1]){
	            b=false;
	            break;
	        }
	    if(b){
		System.out.println(arr[i]+" ");
	}
}
}
}