import java.util.*;

public class Main {
    public static void main(String[] args) {
       
        List<Integer> numbers = new ArrayList<>();
        numbers.add(2);
        numbers.add(4);
        numbers.add(6);
        numbers.add(8);

        
        Collections.reverse(numbers);

        
        System.out.println("Reversed List: " + numbers);
    }
}
