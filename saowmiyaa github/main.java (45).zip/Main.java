import java.util.Scanner;
public class Main{
    public static void main(String[]args){
        Scanner out=new Scanner(System.in);
        int n=out.nextInt();
        int a=out.nextInt(),b=out.nextInt(),c=out.nextInt(),d=out.nextInt(),e=out.nextInt();
        int sum=a+b+c+d+e;
        System.out.println(sum);
    }
    }