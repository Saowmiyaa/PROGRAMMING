public class Main {
    public static void main(String[] args) {
        String s = "HELLO";
        int n = s.length();

        for (int i = 0; i < n; i++) {
            System.out.print(s.charAt(i) + " ");
        }
        System.out.println();

        for (int i = 1; i < n - 1; i++) {
            System.out.print(s.charAt(i));
            for (int j = 1; j <= 2 * (n - 2) + 1; j++) {
                System.out.print(" ");
            }
            System.out.println(s.charAt(n - i - 1));
        }
        for (int i = n - 1; i >= 0; i--) {
            System.out.print(s.charAt(i) + " ");
        }
    }
}
