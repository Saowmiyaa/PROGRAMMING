import java.util.Scanner;
public class Main{
    public static void main(String[]args){
        Scanner out=new Scanner(System.in);
        String a=out.nextLine();
        out.nextLine();
        int count=0;
        for(int i=1;i<=a.length();i++){
            count++;
        }
        System.out.println(count);
    }
}