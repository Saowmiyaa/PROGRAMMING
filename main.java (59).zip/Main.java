import java.util.Scanner;
public class Main{
    public static void main(String[]args){
        Scanner out=new Scanner(System.in);
        int n=out.nextInt();
        out.nextLine();
        String a=out.nextLine();
        String b=out.nextLine();
        String c=out.nextLine();
        String d=out.nextLine();
        String e=out.nextLine();
        System.out.println(a);
        System.out.println(c);
        System.out.println(e);
        
        
        
    }
}