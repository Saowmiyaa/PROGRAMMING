import java.util.Scanner;


public class Main {

    public static void main(String[] args) {
        Scanner out=new Scanner(System.in);
        
        System.out.println("Enter a number");
        int n1=out.nextInt();
        int count=0;
        while(n1!=1){
           System.out.println(n1); 
        if(n1%2!=0){
            n1= 3*n1+1;
            
        }
    
        else{
          n1=n1/2;
        }
        count++;
        
    }
    System.out.println(n1);
    System.out.println("Count:"+count);
    }
}
