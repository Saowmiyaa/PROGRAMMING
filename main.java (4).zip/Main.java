import java.util.Scanner;
public class Main{
    public static void main(String[]args){
        Scanner out=new Scanner(System.in);
        int r=out.nextInt(),c=out.nextInt();
        int a[][]=new int[r][c];
        int b[][]=new int[r][c];
        int sum[][]=new int[r][c];
        for(int i=0;i<r;i++)
             for(int j=0;j<c;j++)
            a[i][j]=out.nextInt();
        
        for(int i=0;i<r;i++)
        for(int j=0;j<c;j++)
            b[i][j]=out.nextInt();
        
        for(int i=0;i<r;i++){
             for(int j=0;j<c;j++){
            sum[i][j]=a[i][j]+b[i][j];
            System.out.print(sum[i][j]+" ");
             }
            System.out.println();
        }
    } 
}
