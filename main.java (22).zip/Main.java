import java.util.Scanner;
public class Main{
    public  static void main(String[]args){
        Scanner out=new Scanner(System.in);
        int n=out.nextInt();
        int arr[]=new int[n];
        int sum=0;
        for(int i=0;i<n;i++){
            arr[i]=out.nextInt();
            sum=sum+arr[i];
        }
        System.out.println(sum);
        
    }
}