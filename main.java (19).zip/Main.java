import java.util.Scanner;
public class Main{
    public static void main(String[]args){
        int arr[][]={{1,2,3,4},
                    {5,6,7,8},
                    {11,22,33,44},
                    {55,66,77,88}};
        int rows=4,cols=4;
        for(int i=0;i<(rows+cols)-1;i++){
            int r=0,c=0;
            if(i%2==0){
                r=i;
                c=0;
                while(r>=0&&c<rows)
                {
                    System.out.print(arr[r][c]+" ");
                    r--;
                    c++;
                }
            }
            else{
                c=i;
                r=0;
                while(c>=0&&r<cols)
                {
                    System.out.print(arr[r][c]+" ");
                    r++;
                    c--;
                }
            }
        }
    }
}