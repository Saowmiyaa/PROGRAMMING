import java.util.*;
public class Main{
    public static void main(String[]args){
        Scanner out=new Scanner(System.in);
        String a=out.nextLine();
        String b=out.nextLine();
        char[]arr=a.toCharArray();
        char[]arr1=a.toCharArray();
        Arrays.sort(arr);
        Arrays.sort(arr1);
        if(Arrays.equals(arr,arr1)){
             System.out.println("Yes");
         }
         else{
             System.out.println("no");
         }
    }
}