import java.util.Scanner;

public class Main {
   
    public static long isqrt(long n) {
        if (n < 0) throw new IllegalArgumentException("n must be non-negative");
        long left = 0;
        long right = n;
        long ans = 0;

        while (left <= right) {
            long mid = left + ((right - left) >> 1); 
            if (mid == 0) {
                ans = 0;
                left = 1;
                continue;
            }
            
            if (mid <= n / mid) { 
                ans = mid;        
                left = mid + 1;   
            } else {
                right = mid - 1;  
            }
        }
        return ans;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        long n = sc.nextLong();      
        System.out.println(isqrt(n)); 
        sc.close();
    }
}
