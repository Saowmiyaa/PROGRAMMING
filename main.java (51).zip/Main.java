import java.util.Scanner;
public class Main{
    public static void main(String[]args){
        Scanner out=new Scanner(System.in);
        int n=out.nextInt();
        int a=out.nextInt();
        int b=out.nextInt();
        int c=out.nextInt();
        int d=out.nextInt();
        int e=a+b+c+d-3;
        System.out.println(e);
    }
    
}