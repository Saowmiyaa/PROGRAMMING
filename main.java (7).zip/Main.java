import java.util.Scanner;
public class Main{
    public static void main(String[]args){
        Scanner out=new Scanner(System.in);
        int n=out.nextInt();
        for(int i=2;i<=n;i++){
            boolean prime=true;
        
        for(int j=2;j<=i/2;j++){
            if(i%j==0){prime=false;break;}
        }
        if(prime)System.out.print(i+" ");
    }
    }
}